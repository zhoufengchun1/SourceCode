﻿using System.Windows.Forms;

namespace PMS
{
    public partial class 帮助 : Form
    {
        public 帮助()
        {
            InitializeComponent();
        }
    }
}