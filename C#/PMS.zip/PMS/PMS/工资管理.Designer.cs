﻿namespace PMS
{
    partial class 工资管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pMSDataSet2 = new PMS.PMSDataSet2();
            this.sALARYTableAdapter = new PMS.PMSDataSet2TableAdapters.SALARYTableAdapter();
            this.pMSDataSet5 = new PMS.PMSDataSet5();
            this.wITHHOLDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wITHHOLDTableAdapter = new PMS.PMSDataSet5TableAdapters.WITHHOLDTableAdapter();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.withholdtable = new System.Windows.Forms.DataGridView();
            this.wITHHOLDIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.snoDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wITHHOLDTIMEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wITHHOLDBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pMSDataSet22 = new PMS.PMSDataSet22();
            this.wITHHOLDIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.snoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wITHHOLDTIMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.salarytable = new System.Windows.Forms.DataGridView();
            this.sALARYIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.snoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deptnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grosspayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paytimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sALARYBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.pMSDataSet20 = new PMS.PMSDataSet20();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pMSDataSet17 = new PMS.PMSDataSet17();
            this.pMSDataSet9 = new PMS.PMSDataSet9();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.pMSDataSet7 = new PMS.PMSDataSet7();
            this.sALARYTableAdapter1 = new PMS.PMSDataSet7TableAdapters.SALARYTableAdapter();
            this.pMSDataSet8 = new PMS.PMSDataSet8();
            this.sALARYTableAdapter2 = new PMS.PMSDataSet8TableAdapters.SALARYTableAdapter();
            this.sALARYTableAdapter3 = new PMS.PMSDataSet9TableAdapters.SALARYTableAdapter();
            this.attendenceTableAdapter1 = new PMS.PMSDataSet3TableAdapters.ATTENDENCETableAdapter();
            this.pMSDataSet16 = new PMS.PMSDataSet16();
            this.sALARYTableAdapter4 = new PMS.PMSDataSet16TableAdapters.SALARYTableAdapter();
            this.pMSDataSet16BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sALARYTableAdapter5 = new PMS.PMSDataSet17TableAdapters.SALARYTableAdapter();
            this.pMSDataSet19 = new PMS.PMSDataSet19();
            this.sALARYTableAdapter6 = new PMS.PMSDataSet20TableAdapters.SALARYTableAdapter();
            this.wITHHOLDTableAdapter1 = new PMS.PMSDataSet22TableAdapters.WITHHOLDTableAdapter();
            this.pMSDataSet25 = new PMS.PMSDataSet25();
            this.sALARYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sALARYTableAdapter7 = new PMS.PMSDataSet25TableAdapters.SALARYTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wITHHOLDBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.withholdtable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wITHHOLDBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet22)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salarytable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sALARYBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet9)).BeginInit();
            this.tabControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet16BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sALARYBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pMSDataSet2
            // 
            this.pMSDataSet2.DataSetName = "PMSDataSet2";
            this.pMSDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYTableAdapter
            // 
            this.sALARYTableAdapter.ClearBeforeFill = true;
            // 
            // pMSDataSet5
            // 
            this.pMSDataSet5.DataSetName = "PMSDataSet5";
            this.pMSDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // wITHHOLDBindingSource
            // 
            this.wITHHOLDBindingSource.RaiseListChangedEvents = false;
            // 
            // wITHHOLDTableAdapter
            // 
            this.wITHHOLDTableAdapter.ClearBeforeFill = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.ID);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.textBox12);
            this.tabPage3.Controls.Add(this.textBox11);
            this.tabPage3.Controls.Add(this.textBox5);
            this.tabPage3.Controls.Add(this.textBox7);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.withholdtable);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(834, 499);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "工资代扣";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(399, 368);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 38);
            this.button3.TabIndex = 59;
            this.button3.Text = "刷新";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(177, 432);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 27);
            this.label9.TabIndex = 58;
            this.label9.Text = "工号";
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.ID.Location = new System.Drawing.Point(21, 430);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(35, 27);
            this.ID.TabIndex = 57;
            this.ID.Text = "ID";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(666, 368);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 38);
            this.button1.TabIndex = 56;
            this.button1.Text = "删除";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(104, 436);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(60, 21);
            this.textBox12.TabIndex = 55;
            this.textBox12.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(693, 436);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(106, 21);
            this.textBox11.TabIndex = 53;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(256, 436);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(106, 21);
            this.textBox5.TabIndex = 51;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(506, 436);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(106, 21);
            this.textBox7.TabIndex = 48;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(13, 432);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 27);
            this.label12.TabIndex = 54;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(541, 368);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(71, 38);
            this.button2.TabIndex = 52;
            this.button2.Text = "写入";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(187, 432);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 27);
            this.label4.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(635, 432);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 27);
            this.label5.TabIndex = 46;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(368, 432);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 27);
            this.label10.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(8, 359);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 25);
            this.label6.TabIndex = 43;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(8, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 25);
            this.label11.TabIndex = 42;
            // 
            // withholdtable
            // 
            this.withholdtable.AutoGenerateColumns = false;
            this.withholdtable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.withholdtable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.wITHHOLDIDDataGridViewTextBoxColumn1,
            this.snoDataGridViewTextBoxColumn2,
            this.rIDDataGridViewTextBoxColumn1,
            this.wITHHOLDTIMEDataGridViewTextBoxColumn1});
            this.withholdtable.DataSource = this.wITHHOLDBindingSource1;
            this.withholdtable.Location = new System.Drawing.Point(26, 38);
            this.withholdtable.Name = "withholdtable";
            this.withholdtable.RowTemplate.Height = 23;
            this.withholdtable.Size = new System.Drawing.Size(711, 310);
            this.withholdtable.TabIndex = 41;
            // 
            // wITHHOLDIDDataGridViewTextBoxColumn1
            // 
            this.wITHHOLDIDDataGridViewTextBoxColumn1.DataPropertyName = "WITHHOLDID";
            this.wITHHOLDIDDataGridViewTextBoxColumn1.HeaderText = "WITHHOLDID";
            this.wITHHOLDIDDataGridViewTextBoxColumn1.Name = "wITHHOLDIDDataGridViewTextBoxColumn1";
            // 
            // snoDataGridViewTextBoxColumn2
            // 
            this.snoDataGridViewTextBoxColumn2.DataPropertyName = "Sno";
            this.snoDataGridViewTextBoxColumn2.HeaderText = "Sno";
            this.snoDataGridViewTextBoxColumn2.Name = "snoDataGridViewTextBoxColumn2";
            // 
            // rIDDataGridViewTextBoxColumn1
            // 
            this.rIDDataGridViewTextBoxColumn1.DataPropertyName = "RID";
            this.rIDDataGridViewTextBoxColumn1.HeaderText = "RID";
            this.rIDDataGridViewTextBoxColumn1.Name = "rIDDataGridViewTextBoxColumn1";
            // 
            // wITHHOLDTIMEDataGridViewTextBoxColumn1
            // 
            this.wITHHOLDTIMEDataGridViewTextBoxColumn1.DataPropertyName = "WITHHOLDTIME";
            this.wITHHOLDTIMEDataGridViewTextBoxColumn1.HeaderText = "WITHHOLDTIME";
            this.wITHHOLDTIMEDataGridViewTextBoxColumn1.Name = "wITHHOLDTIMEDataGridViewTextBoxColumn1";
            // 
            // wITHHOLDBindingSource1
            // 
            this.wITHHOLDBindingSource1.DataMember = "WITHHOLD";
            this.wITHHOLDBindingSource1.DataSource = this.pMSDataSet22;
            // 
            // pMSDataSet22
            // 
            this.pMSDataSet22.DataSetName = "PMSDataSet22";
            this.pMSDataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // wITHHOLDIDDataGridViewTextBoxColumn
            // 
            this.wITHHOLDIDDataGridViewTextBoxColumn.DataPropertyName = "WITHHOLDID";
            this.wITHHOLDIDDataGridViewTextBoxColumn.HeaderText = "WITHHOLDID";
            this.wITHHOLDIDDataGridViewTextBoxColumn.Name = "wITHHOLDIDDataGridViewTextBoxColumn";
            // 
            // snoDataGridViewTextBoxColumn1
            // 
            this.snoDataGridViewTextBoxColumn1.DataPropertyName = "Sno";
            this.snoDataGridViewTextBoxColumn1.HeaderText = "Sno";
            this.snoDataGridViewTextBoxColumn1.Name = "snoDataGridViewTextBoxColumn1";
            // 
            // rIDDataGridViewTextBoxColumn
            // 
            this.rIDDataGridViewTextBoxColumn.DataPropertyName = "RID";
            this.rIDDataGridViewTextBoxColumn.HeaderText = "RID";
            this.rIDDataGridViewTextBoxColumn.Name = "rIDDataGridViewTextBoxColumn";
            // 
            // wITHHOLDTIMEDataGridViewTextBoxColumn
            // 
            this.wITHHOLDTIMEDataGridViewTextBoxColumn.DataPropertyName = "WITHHOLDTIME";
            this.wITHHOLDTIMEDataGridViewTextBoxColumn.HeaderText = "WITHHOLDTIME";
            this.wITHHOLDTIMEDataGridViewTextBoxColumn.Name = "wITHHOLDTIMEDataGridViewTextBoxColumn";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.salarytable);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(834, 499);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "工资查询";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(622, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 23);
            this.label7.TabIndex = 49;
            this.label7.Text = "时间";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(410, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 27);
            this.label3.TabIndex = 48;
            this.label3.Text = "部门编号";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(227, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 28);
            this.label2.TabIndex = 47;
            this.label2.Text = "姓名";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(17, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 30);
            this.label1.TabIndex = 46;
            this.label1.Text = "工号";
            // 
            // salarytable
            // 
            this.salarytable.AllowUserToOrderColumns = true;
            this.salarytable.AutoGenerateColumns = false;
            this.salarytable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.salarytable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sALARYIDDataGridViewTextBoxColumn,
            this.snoDataGridViewTextBoxColumn,
            this.deptnoDataGridViewTextBoxColumn,
            this.grosspayDataGridViewTextBoxColumn,
            this.paytimeDataGridViewTextBoxColumn});
            this.salarytable.DataSource = this.sALARYBindingSource;
            this.salarytable.Location = new System.Drawing.Point(57, 112);
            this.salarytable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.salarytable.Name = "salarytable";
            this.salarytable.RowTemplate.Height = 23;
            this.salarytable.Size = new System.Drawing.Size(720, 298);
            this.salarytable.TabIndex = 45;
            // 
            // sALARYIDDataGridViewTextBoxColumn
            // 
            this.sALARYIDDataGridViewTextBoxColumn.DataPropertyName = "SALARYID";
            this.sALARYIDDataGridViewTextBoxColumn.HeaderText = "SALARYID";
            this.sALARYIDDataGridViewTextBoxColumn.Name = "sALARYIDDataGridViewTextBoxColumn";
            // 
            // snoDataGridViewTextBoxColumn
            // 
            this.snoDataGridViewTextBoxColumn.DataPropertyName = "Sno";
            this.snoDataGridViewTextBoxColumn.HeaderText = "Sno";
            this.snoDataGridViewTextBoxColumn.Name = "snoDataGridViewTextBoxColumn";
            // 
            // deptnoDataGridViewTextBoxColumn
            // 
            this.deptnoDataGridViewTextBoxColumn.DataPropertyName = "Deptno";
            this.deptnoDataGridViewTextBoxColumn.HeaderText = "Deptno";
            this.deptnoDataGridViewTextBoxColumn.Name = "deptnoDataGridViewTextBoxColumn";
            // 
            // grosspayDataGridViewTextBoxColumn
            // 
            this.grosspayDataGridViewTextBoxColumn.DataPropertyName = "Grosspay";
            this.grosspayDataGridViewTextBoxColumn.HeaderText = "Grosspay";
            this.grosspayDataGridViewTextBoxColumn.Name = "grosspayDataGridViewTextBoxColumn";
            // 
            // paytimeDataGridViewTextBoxColumn
            // 
            this.paytimeDataGridViewTextBoxColumn.DataPropertyName = "Paytime";
            this.paytimeDataGridViewTextBoxColumn.HeaderText = "Paytime";
            this.paytimeDataGridViewTextBoxColumn.Name = "paytimeDataGridViewTextBoxColumn";
            // 
            // sALARYBindingSource6
            // 
            this.sALARYBindingSource6.DataMember = "SALARY";
            this.sALARYBindingSource6.DataSource = this.pMSDataSet20;
            // 
            // pMSDataSet20
            // 
            this.pMSDataSet20.DataSetName = "PMSDataSet20";
            this.pMSDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(706, 38);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(96, 21);
            this.textBox3.TabIndex = 44;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(308, 34);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(96, 21);
            this.textBox2.TabIndex = 36;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(102, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(96, 21);
            this.textBox1.TabIndex = 35;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06"});
            this.comboBox1.Location = new System.Drawing.Point(509, 34);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(96, 20);
            this.comboBox1.TabIndex = 39;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(384, 63);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(70, 44);
            this.button6.TabIndex = 31;
            this.button6.Text = "查询";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(451, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 27);
            this.label8.TabIndex = 30;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(651, 34);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 27);
            this.label14.TabIndex = 27;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(240, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 27);
            this.label17.TabIndex = 24;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(34, 31);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 27);
            this.label18.TabIndex = 23;
            // 
            // pMSDataSet17
            // 
            this.pMSDataSet17.DataSetName = "PMSDataSet17";
            this.pMSDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pMSDataSet9
            // 
            this.pMSDataSet9.DataSetName = "PMSDataSet9";
            this.pMSDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(9, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(842, 525);
            this.tabControl1.TabIndex = 0;
            // 
            // pMSDataSet7
            // 
            this.pMSDataSet7.DataSetName = "PMSDataSet7";
            this.pMSDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYTableAdapter1
            // 
            this.sALARYTableAdapter1.ClearBeforeFill = true;
            // 
            // pMSDataSet8
            // 
            this.pMSDataSet8.DataSetName = "PMSDataSet8";
            this.pMSDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYTableAdapter2
            // 
            this.sALARYTableAdapter2.ClearBeforeFill = true;
            // 
            // sALARYTableAdapter3
            // 
            this.sALARYTableAdapter3.ClearBeforeFill = true;
            // 
            // attendenceTableAdapter1
            // 
            this.attendenceTableAdapter1.ClearBeforeFill = true;
            // 
            // pMSDataSet16
            // 
            this.pMSDataSet16.DataSetName = "PMSDataSet16";
            this.pMSDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYTableAdapter4
            // 
            this.sALARYTableAdapter4.ClearBeforeFill = true;
            // 
            // pMSDataSet16BindingSource
            // 
            this.pMSDataSet16BindingSource.RaiseListChangedEvents = false;
            // 
            // sALARYTableAdapter5
            // 
            this.sALARYTableAdapter5.ClearBeforeFill = true;
            // 
            // pMSDataSet19
            // 
            this.pMSDataSet19.DataSetName = "PMSDataSet19";
            this.pMSDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYTableAdapter6
            // 
            this.sALARYTableAdapter6.ClearBeforeFill = true;
            // 
            // wITHHOLDTableAdapter1
            // 
            this.wITHHOLDTableAdapter1.ClearBeforeFill = true;
            // 
            // pMSDataSet25
            // 
            this.pMSDataSet25.DataSetName = "PMSDataSet25";
            this.pMSDataSet25.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALARYBindingSource
            // 
            this.sALARYBindingSource.DataMember = "SALARY";
            this.sALARYBindingSource.DataSource = this.pMSDataSet25;
            // 
            // sALARYTableAdapter7
            // 
            this.sALARYTableAdapter7.ClearBeforeFill = true;
            // 
            // 工资管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(897, 515);
            this.Controls.Add(this.tabControl1);
            this.Location = new System.Drawing.Point(15, 15);
            this.Name = "工资管理";
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wITHHOLDBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.withholdtable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wITHHOLDBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet22)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salarytable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sALARYBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet9)).EndInit();
            this.tabControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet16BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pMSDataSet25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sALARYBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PMS.PMSDataSet2 pMSDataSet2;
        private PMS.PMSDataSet2TableAdapters.SALARYTableAdapter sALARYTableAdapter;
        private PMS.PMSDataSet5 pMSDataSet5;
        private System.Windows.Forms.BindingSource wITHHOLDBindingSource;
        private PMS.PMSDataSet5TableAdapters.WITHHOLDTableAdapter wITHHOLDTableAdapter;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView withholdtable;
        private System.Windows.Forms.DataGridViewTextBoxColumn wITHHOLDIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn snoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wITHHOLDTIMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabControl tabControl1;
        private PMS.PMSDataSet7 pMSDataSet7;
        private PMS.PMSDataSet7TableAdapters.SALARYTableAdapter sALARYTableAdapter1;
        private PMS.PMSDataSet8 pMSDataSet8;
        private PMS.PMSDataSet8TableAdapters.SALARYTableAdapter sALARYTableAdapter2;
        private PMS.PMSDataSet9 pMSDataSet9;
        private PMS.PMSDataSet9TableAdapters.SALARYTableAdapter sALARYTableAdapter3;
        private PMS.PMSDataSet3TableAdapters.ATTENDENCETableAdapter attendenceTableAdapter1;
        private System.Windows.Forms.DataGridView salarytable;
        private System.Windows.Forms.Button button1;
        private PMS.PMSDataSet16 pMSDataSet16;
        private PMS.PMSDataSet16TableAdapters.SALARYTableAdapter sALARYTableAdapter4;
        private System.Windows.Forms.BindingSource pMSDataSet16BindingSource;
        private PMS.PMSDataSet17 pMSDataSet17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private PMS.PMSDataSet17TableAdapters.SALARYTableAdapter sALARYTableAdapter5;
        private PMSDataSet19 pMSDataSet19;
        private PMSDataSet20 pMSDataSet20;
        private System.Windows.Forms.BindingSource sALARYBindingSource6;
        private PMSDataSet20TableAdapters.SALARYTableAdapter sALARYTableAdapter6;
        private System.Windows.Forms.DataGridViewTextBoxColumn sALARYIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn snoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deptnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn grosspayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paytimeDataGridViewTextBoxColumn;
        private PMSDataSet22 pMSDataSet22;
        private System.Windows.Forms.BindingSource wITHHOLDBindingSource1;
        private PMSDataSet22TableAdapters.WITHHOLDTableAdapter wITHHOLDTableAdapter1;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn wITHHOLDIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn snoDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn wITHHOLDTIMEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label9;
        private PMSDataSet25 pMSDataSet25;
        private System.Windows.Forms.BindingSource sALARYBindingSource;
        private PMSDataSet25TableAdapters.SALARYTableAdapter sALARYTableAdapter7;
    }
}